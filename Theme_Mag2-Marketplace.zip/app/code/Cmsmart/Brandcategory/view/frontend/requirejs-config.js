var config = {
    paths: {
        'cmsmartCarousel': 'Cmsmart_Brandcategory/js/brands',     
        'cmsmartBrand': 'Cmsmart_Brandcategory/js/owl_carousel/owl.carousel'     
    },
    shim: {
            'cmsmartBrand': {
                deps: ['jquery']
            },
			'cmsmartCarousel': {
                deps: ['jquery']
            }
        }

};