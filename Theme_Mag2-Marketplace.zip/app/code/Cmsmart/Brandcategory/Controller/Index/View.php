<?php

namespace Cmsmart\Brandcategory\Controller\Index;

use Cmsmart\Brandcategory\Controller\BrandcategoryInterface;

class View extends \Cmsmart\Brandcategory\Controller\AbstractController\View implements BrandcategoryInterface
{

}
