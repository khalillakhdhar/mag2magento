<?php

namespace Cmsmart\Brandcategory\Controller;

use Magento\Framework\App\ActionInterface;

interface BrandcategoryInterface extends ActionInterface
{
}
