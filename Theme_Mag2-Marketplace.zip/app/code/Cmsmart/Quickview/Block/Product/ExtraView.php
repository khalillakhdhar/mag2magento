<?php

namespace Cmsmart\Quickview\Block\Product;

use Magento\Catalog\Block\Product\AbstractProduct;

class ExtraView extends AbstractProduct
{

}