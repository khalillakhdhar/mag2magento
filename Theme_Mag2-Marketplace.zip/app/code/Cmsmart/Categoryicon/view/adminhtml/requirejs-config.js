var config = {
    paths: {
        cmsmartTreeview: 'Cmsmart_Categoryicon/js/treeview/jquery.treeview'     
    },
    shim: {
            'cmsmartTreeview': {
                deps: ['jquery']
            }
        }

};