<?php

namespace Cmsmart\Categoryicon\Controller\Index;

use Cmsmart\Categoryicon\Controller\CategoryiconInterface;

class View extends \Cmsmart\Categoryicon\Controller\AbstractController\View implements CategoryiconInterface
{

}
