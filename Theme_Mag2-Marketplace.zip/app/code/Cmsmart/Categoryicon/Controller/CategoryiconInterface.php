<?php

namespace Cmsmart\Categoryicon\Controller;

use Magento\Framework\App\ActionInterface;

interface CategoryiconInterface extends ActionInterface
{
}
