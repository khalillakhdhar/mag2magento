var config = {

	paths: {
		"adminColorpicker" : "Cmsmart_Megamenu/js/colorpicker/js/colorpicker"
    },
	shim: {
            'adminColorpicker': {
                deps: ['jquery']
            }
        }
}

