<?php

namespace Cmsmart\Megamenu\Controller\Index;

use Cmsmart\Megamenu\Controller\MegamenuInterface;

class View extends \Cmsmart\Megamenu\Controller\AbstractController\View implements MegamenuInterface
{

}
