<?php

namespace Cmsmart\Megamenu\Controller;

use Magento\Framework\App\ActionInterface;

interface MegamenuInterface extends ActionInterface
{
}
