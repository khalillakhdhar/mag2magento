<?php

namespace Netbase\Product\Controller\Index;

use Netbase\Product\Controller\ProductInterface;

class View extends \Netbase\Product\Controller\AbstractController\View implements ProductInterface
{

}
