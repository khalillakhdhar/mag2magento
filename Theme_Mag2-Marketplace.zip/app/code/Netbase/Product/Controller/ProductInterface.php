<?php

namespace Netbase\Product\Controller;

use Magento\Framework\App\ActionInterface;

interface ProductInterface extends ActionInterface
{
}
