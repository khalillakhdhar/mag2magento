<?php
/**
 * Copyright © 2015 Netbasecommerce. All rights reserved.
 */
namespace Netbase\Product\Model;

class Homepagetype
{
	const custom_static_block = 9;
}
